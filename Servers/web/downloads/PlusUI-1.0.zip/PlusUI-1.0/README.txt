PlusUI 1.0 - the PlusOS GUI framework, Designer and code generator
====================================================================

What is in this archive
-----------------------
  tools/uidesigner/designer.py     PlusUI Designer: draw forms with the mouse
  tools/uidesigner/puigen.py       turns a saved .pui design into C or C++ source
  tools/uidesigner/puimodel.py     the .pui project model (shared)
  tools/uidesigner/puirender.py    pixel-exact form renderer used by the Designer
  tools/uidesigner/test/           headless tests (run on the emulator's 68k core)
  sdks/macplus/.../ui.h, ui.c      the PlusUI framework (same files under sdks/macse)
  apps/development/uidemo/         a complete example app, designed and generated
  docs/08_PLUSUI_GUI_FRAMEWORK.md  the manual

Just want to design a form?
---------------------------
You only need Python 3 (3.8 or newer) with tkinter, which the standard Windows and
macOS installers include. Nothing else to install.

    Windows:        tools\uidesigner\designer.cmd
    macOS / Linux:  sh tools/uidesigner/designer.sh
    any:            python tools/uidesigner/designer.py [project.pui]

Draw the form, File > Save, and send the .pui file to whoever builds the app.
Try it on the example:  python tools/uidesigner/designer.py apps/development/uidemo/uidemo.pui

Want to build apps with it?
---------------------------
Copy the sdks/, tools/, apps/ and docs/ folders from this archive over your PlusOS
source folder (they only add files). Then:

    python tools/uidesigner/puigen.py apps/tools/myapp/myapp.pui
    make.cmd apps

PlusOS sources newer than this archive already contain all of it.

Full instructions: docs/08_PLUSUI_GUI_FRAMEWORK.md, or the PlusUI chapter of the wiki.
